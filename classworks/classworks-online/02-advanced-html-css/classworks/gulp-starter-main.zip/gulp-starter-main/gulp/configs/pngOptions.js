export const pngOptions = {
	optimizationLevel: 3,
	bitDepthReduction: true,
	colorTypeReduction: true,
	paletteReduction: true,
	interlaced: null,
	errorRecovery: true,
};
