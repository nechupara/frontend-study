export const avifOptions = {
	quality: 75,
	lossless: false,
	speed: 0,
};
