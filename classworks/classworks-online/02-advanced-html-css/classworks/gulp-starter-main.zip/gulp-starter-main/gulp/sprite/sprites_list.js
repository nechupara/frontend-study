export const sprites_src = {
	"sprite": {
		"sprite_src": "/images/sprites/main/sprite_src",
		"sprite_inline": "/images/sprites/main/",
		"scss": "_sprite.scss"
	}
}
